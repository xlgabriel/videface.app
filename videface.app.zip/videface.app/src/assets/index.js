import brainwave from "./brainwave.svg";
import check from "./check.svg";
import brainwaveSymbol from "./brainwave-symbol.svg";
import brainwaveWhiteSymbol from "./brainwave-symbol-white.svg";
import play from "./play.svg";
import grid from "./grid.png";
import check2 from "./check-02.svg";
import loading1 from "./loading-01.svg";
import companyLogo1 from "./logo01.png";
import companyLogo2 from "./logo02.png";
import companyLogo3 from "./logo03.png";
import companyLogo4 from "./logo04.png";
import yourlogo from "./logo05.png";
import companyLogo6 from "./logo06.png";
import companyLogo7 from "./nordic.svg";
import homeSmile from "./home-smile.png";
import file02 from "./file-02.png";
import searchMd from "./search-md.png";
import plusSquare from "./plus-square.png";
import plusSquareWhite from "./plus-square-white.png";
import recording03 from "./recording-03.svg";
import recording01 from "./recording-01.svg";
import disc02 from "./plus-square.png";
import chromecast from "./chrome-cast.svg";
import sliders04 from "./sliders-04.svg";
import loading from "./loading.png";
import gradient from "./gradient.png";
import lightmode from "./lightmode.svg";
import darkmode from "./darkmode.svg";

import curve from "./hero/curve.png";
import heroBackground from "./hero/hero-background.webp";
import homeOG from "./OG/homeOG.webp";
import kioskOG from "./OG/KioskOG.webp";

import curve1 from "./collaboration/curve-1.svg";
import curve2 from "./collaboration/curve-2.svg";

import discord from "./collaboration/discord.svg";
import figma from "./collaboration/figma.svg";
import framer from "./collaboration/framer.png";
import notion from "./collaboration/notion.svg";
import photoshop from "./collaboration/photoshop.png";
import protopie from "./collaboration/protopie.png";
import raindrop from "./collaboration/raindrop.png";
import slack from "./collaboration/slack.png";

import service1 from "./services/service-1.webp";
import service1mobile from "./services/service-1-mobile.webp";
import service2 from "./services/service-2.webp";
import service3 from "./services/service-3.webp";

import lines from "./pricing/lines.svg";
import stars from "./pricing/stars.svg";

// Roadmap images removed — references cleaned

import notification1 from "./notification/image-1.png";
import notification2 from "./notification/image-2.png";
import notification3 from "./notification/image-3.png";
import notification4 from "./notification/image-4.png";

import benefitCard1 from "./benefits/card-1.png";
import benefitCard2 from "./benefits/card-2.png";
import benefitCard3 from "./benefits/card-3.png";
import benefitCard4 from "./benefits/card-4.png";
import benefitCard5 from "./benefits/card-5.png";
import benefitCard6 from "./benefits/card-6.png";
import benefitIcon1 from "./benefits/icon-1.svg";
import benefitIcon2 from "./benefits/icon-2.svg";
import benefitIcon3 from "./benefits/icon-3.svg";
import benefitIcon4 from "./benefits/icon-4.svg";
import benefitIcon5 from "./benefits/icon-5.svg";
import benefitIcon6 from "./benefits/icon-6.svg";
import benefitImage1 from "./benefits/image-1.webp";
import benefitImage2 from "./benefits/image-2.webp";
import benefitImage3 from "./benefits/image-3.webp";
import benefitImage4 from "./benefits/image-4.webp";
import benefitImage5 from "./benefits/image-5.webp";
import benefitImage6 from "./benefits/image-6.webp";

import discordBlack from "./socials/discord.svg";
import facebook from "./socials/facebook.svg";
import instagram from "./socials/instagram.svg";
import telegram from "./socials/telegram.svg";
import twitter from "./socials/twitter.svg";
import youtube from "./socials/youtube.svg";

/* import message1 from "./message1.webp"; */

import logowhite from "./LogoWhite.png";
import Economy from "./LogosCompanies/Economy.png";
import Mex from "./LogosCompanies/Mex.png";
import Awreck from "./LogosCompanies/Awreck.png";
import RC from "./LogosCompanies/RC.png";
import Nextcar from "./LogosCompanies/Nextcar.png";
import Advantage from "./LogosCompanies/Advantage.png";
import Nu from "./LogosCompanies/Nu.png";
import Routes from "./LogosCompanies/Routes.png";
import priceless from "./LogosCompanies/priceless.png";
import Wheego from "./LogosCompanies/Wheego.png";
import Flexways from "./LogosCompanies/Flexways.png";
import Zezgo from "./LogosCompanies/Zezgo.png";
import Flextogo from "./LogosCompanies/Flextogo.png";
import Zoom from "./LogosCompanies/Zoom.png";
import Carwiz from "./LogosCompanies/Carwiz.png";
import Autounion from "./LogosCompanies/Autounion.png";
import york from "./LogosCompanies/york.png";
import ACO from "./LogosCompanies/ACO.png";
import tht from "./LogosCompanies/tht.png";
import cargreen from "./LogosCompanies/cargreen.png";
import Colusa from "./LogosCompanies/Colusa.png";
import oneswitch from "./LogosCompanies/oneswitch.png";
import Clubs from "./LogosCompanies/Clubs.png";
import Nordic from "./LogosCompanies/Nordic.png";
import amerirent from "./LogosCompanies/amerirent.png";
import Cafe from "./LogosCompanies/Cafe.png";
import Tarpon from "./LogosCompanies/4.png";
import Final from "./LogosCompanies/Final.png";
import seven24 from "./LogosCompanies/24seven.png";
import Nola from "./LogosCompanies/Nola.png";
import Flex from "./LogosCompanies/Flex.png";

export {
    gradient,
    logowhite,
    brainwave,
    check,
    check2,
    loading1,
    brainwaveSymbol,
    brainwaveWhiteSymbol,
    play,
    grid,
    companyLogo1,
    companyLogo2,
    companyLogo3,
    companyLogo4,
    companyLogo6,
    companyLogo7,
    yourlogo,
    homeSmile,
    file02,
    searchMd,
    plusSquare,
    plusSquareWhite,
    recording03,
    recording01,
    disc02,
    chromecast,
    sliders04,
    loading,
    curve,
    heroBackground,
    homeOG,
    kioskOG,
    curve1,
    curve2,
    discord,
    figma,
    framer,
    notion,
    photoshop,
    protopie,
    raindrop,
    slack,
    service1,
    service1mobile,
    service2,
    service3,
    lines,
    stars,
    // roadmap images removed
    notification1,
    notification2,
    notification3,
    notification4,
    benefitCard1,
    benefitCard2,
    benefitCard3,
    benefitCard4,
    benefitCard5,
    benefitCard6,
    benefitIcon1,
    benefitIcon2,
    benefitIcon3,
    benefitIcon4,
    benefitIcon5,
    benefitIcon6,
    benefitImage1,
    benefitImage2,
    benefitImage3,
    benefitImage4,
    benefitImage5,
    benefitImage6,
    discordBlack,
    facebook,
    instagram,
    telegram,
    twitter,
    youtube,
    lightmode,
    darkmode,
    // message1 removed
    // LogosCompanies
    Economy,
    Mex,
    Awreck,
    RC,
    Nextcar,
    Advantage,
    Nu,
    Routes,
    priceless,
    Wheego,
    Flexways,
    Zezgo,
    Flextogo,
    Zoom,
    Carwiz,
    Autounion,
    york,
    ACO,
    tht,
    cargreen,
    Colusa,
    oneswitch,
    Clubs,
    Nordic,
    amerirent,
    Cafe,
    Tarpon,
    Final,
    seven24,
    Nola,
    Flex,
};
