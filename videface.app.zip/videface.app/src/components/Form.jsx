import React, { useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import Button from "./Button";
import Heading from "./Heading";
import Section from "./Section";
import { gradient } from "../assets";
import { BackgroundCircles } from "./design/Hero";
import ReactDOMServer from "react-dom/server";
import ContactEmailTemplate from "./ContactEmailTemplate";

// USA phone: digits only, max 10, display as (XXX) XXX-XXXX
const formatUSAPhone = (digits) => {
    const d = (digits || "").replace(/\D/g, "").slice(0, 10);
    if (d.length <= 3) return d;
    if (d.length <= 6) return `(${d.slice(0, 3)}) ${d.slice(3)}`;
    return `(${d.slice(0, 3)}) ${d.slice(3, 6)}-${d.slice(6)}`;
};

const Form = () => {
    const navigate = useNavigate();
    const formRef = useRef();
    const [form, setForm] = useState({
        name: "",
        company: "",
        email: "",
        message: "",
        cars: "<100",
        phone: "",
        wantsToSchedule: false,
    });

    const [loading, setLoading] = useState(false);
    const [emailSent, setEmailSent] = useState(false);
    const [errors, setErrors] = useState({
        name: false,
        company: false,
        email: false,
    });

    // ✅ Instead of concatenating everything into a single string,
    // we pass all values individually to the template
    const emailContact = ReactDOMServer.renderToString(
        <ContactEmailTemplate
            name={form.name}
            email={form.email}
            company={form.company}
            phone={form.phone}
            message={`Number of Cars: ${form.cars}\n\n${form.message}`}
        />
    );

    const emailConfig = {
        subject: "Thank you for contacting VideFace!",
        from: "VideFace",
        receiverEmails: [
            "admin@videface.com",
            "ariel@videface.com",
            "nathaliabenitez@videface.com ",
            form.email, // the client who wrote
        ],
    };

    //const emailConfig = {
    //    subject: "Thank you for contacting VideFace!",
    //    from: "VideFace",
    //    receiverEmail1: "videfaceapp@gmail.com",
    //    receiverEmail2: form.email,
    //};

    const handleChange = (e) => {
        const { id, value, type, checked } = e.target;
        if (id === "phone") {
            const digitsOnly = value.replace(/\D/g, "").slice(0, 10);
            setForm((prevForm) => ({ ...prevForm, phone: digitsOnly }));
            return;
        }
        setForm((prevForm) => ({
            ...prevForm,
            [id]: type === "checkbox" ? checked : value,
        }));
    };

    const handleSubmit = (e) => {
        e.preventDefault();

        let hasErrors = false;
        const newErrors = {
            name: form.name === "",
            company: form.company === "",
            email: form.email === "",
            message: form.message === "",
        };

        if (newErrors.name || newErrors.company || newErrors.email) {
            hasErrors = true;
        }

        setErrors(newErrors);

        if (hasErrors) {
            return;
        }

        setLoading(true);

        // Localhost test: skip backend when on localhost and email is test@gmail.com
        const isLocalhost =
            typeof window !== "undefined" &&
            /^https?:\/\/localhost(:\d+)?(\/|$)/i.test(window.location.origin);
        const isTestEmail = form.email.trim().toLowerCase() === "test@gmail.com";
        if (isLocalhost && isTestEmail) {
            setLoading(false);
            navigate("/thank-you", {
                replace: true,
                state: { name: form.name, company: form.company, wantsToSchedule: form.wantsToSchedule },
            });
            return;
        }

        const data = {
            name: form.name,
            email: form.email,
            phone: form.phone ? `+1 ${form.phone}` : "+1",
            companyId: "VideFace",
            office: "Webpage",
            emailConfig: emailConfig,
            htmlContactTemplate: emailContact,
        };

        fetch("https://videface-backend-166917106706.us-east1.run.app/api/v1/cars/inspections/emails/contact", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(data),
        })
            .then((response) => response.json())
            .then(
                () => {
                    setLoading(false);
                    navigate("/thank-you", {
                        replace: true,
                        state: { name: form.name, company: form.company, wantsToSchedule: form.wantsToSchedule },
                    });
                },
                (error) => {
                    setLoading(false);
                    console.error(error);

                    alert("Ahh, something went wrong. Please try again.");
                }
            );
    };

    const isMobile = window.innerWidth <= 768;

    return (
        <Section crosses>
            <div className="flex flex-col justify-center items-center h-screen">
                <Heading tag="CONTACT FORM" title="Start with VideFace" />
                <div className="bg-n-14 border border-n-6 rounded-[2rem] p-8 rounded-lg shadow-md max-w-md w-full">
                    <form ref={formRef} onSubmit={handleSubmit}>
                        <div className="mb-4">
                            <label htmlFor="name" className="block mb-1">
                                Client Name
                            </label>
                            <input
                                id="name"
                                type="text"
                                className={`w-full p-2 border ${
                                    errors.name ? "border-n-6" : "border-gray-300"
                                } rounded bg-n-7`}
                                placeholder="Name"
                                value={form.name}
                                onChange={handleChange}
                            />
                            {errors.name && <span className="text-color-5 text-sm">Please, write your name here.</span>}
                        </div>
                        <div className="mb-4">
                            <label htmlFor="company" className="block mb-1">
                                Company Name
                            </label>
                            <input
                                id="company"
                                type="text"
                                className={`w-full p-2 border ${
                                    errors.company ? "border-n-6" : "border-gray-300"
                                } rounded bg-n-7`}
                                placeholder="Company Name"
                                value={form.company}
                                onChange={handleChange}
                            />
                            {errors.company && (
                                <span className="text-color-5 text-sm">Please, write your company's name here.</span>
                            )}
                        </div>
                        <div className="mb-4">
                            <label htmlFor="email" className="block mb-1">
                                Client Email
                            </label>
                            <input
                                id="email"
                                type="email"
                                className={`w-full p-2 border ${
                                    errors.email ? "border-n-6" : "border-gray-300"
                                } rounded bg-n-7`}
                                placeholder="Email"
                                value={form.email}
                                onChange={handleChange}
                            />
                            {errors.email && (
                                <span className="text-color-5 text-sm">Don't forget to write your email.</span>
                            )}
                        </div>
                        <div className="mb-4">
                            <label htmlFor="phone" className="block mb-1">
                                Phone Number
                            </label>
                            <input
                                id="phone"
                                type="tel"
                                inputMode="numeric"
                                autoComplete="tel-national"
                                className="w-full p-2 border border-gray-300 rounded bg-n-7"
                                placeholder="(555) 555-5555"
                                value={formatUSAPhone(form.phone)}
                                onChange={handleChange}
                            />
                        </div>
                        <div className="mb-4">
                            <label htmlFor="message" className="block mb-1">
                                Message (optional)
                            </label>
                            <textarea
                                id="message"
                                className={`w-full p-2 border ${
                                    errors.message ? "border-n-6" : "border-gray-300"
                                } rounded bg-n-7 resize-none h-24`}
                                placeholder="Message"
                                value={form.message}
                                onChange={handleChange}
                            />
                        </div>
                        <div className="mb-4">
                            <label htmlFor="cars" className="block mb-1">
                                Number of Cars
                            </label>
                            <select
                                id="cars"
                                className="w-full p-3 border border-gray-300 rounded bg-n-7 text-lg focus:outline-none focus:ring-2 focus:ring-blue-500 hover:cursor-pointer"
                                value={form.cars}
                                onChange={handleChange}
                            >
                                <option value="<100">Less than 100</option>
                                <option value="100-200">100-200</option>
                                <option value="200-500">200-500</option>
                                <option value="500-1000">500-1000</option>
                                <option value="1000+">1000+</option>
                                <option value="other">Not specified</option>
                            </select>
                        </div>
                        <div className="mb-4">
                            <label className="flex items-center gap-3 cursor-pointer select-none">
                                <input
                                    id="wantsToSchedule"
                                    type="checkbox"
                                    checked={form.wantsToSchedule || false}
                                    onChange={handleChange}
                                    className="h-5 w-5 rounded border-n-6 bg-n-7 text-[#0A6CFF] focus:ring-2 focus:ring-n-6 focus:ring-offset-0 cursor-pointer"
                                    aria-label="I'm interested in scheduling a meeting"
                                />
                                <span className="text-n-1 text-sm font-medium">
                                    I'm interested in scheduling a meeting
                                </span>
                            </label>
                        </div>
                        <Button
                            className={`w-full mb-6 mt-4 ${
                                loading ? "bg-transparent cursor-not-allowed" : "bg-transparent hover:text-n-6"
                            }`}
                            disabled={loading}
                            onClick={handleSubmit}
                        >
                            {loading ? "Sending..." : "Send"}
                        </Button>
                        <p className="text-sm text-center">
                            You can also email to{" "}
                            <a href="mailto:contact@videface.com" className="text-blue-500">
                                contact@videface.com
                            </a>
                        </p>
                        <p className="text-sm text-center mt-1">
                            Or give us a call:{" "}
                            <a href="tel:+14075586889" className="text-blue-500">
                                +1 407 558 6889
                            </a>
                        </p>
                    </form>
                    <div
                        className="absolute -top-[54%] left-1/2 w-[234%] -translate-x-1/2 md:-top-[50%] md:w-[95%] lg:-top-[12%] opacity-25 "
                        style={{ zIndex: -1 }}
                    >
                        <img
                            src={gradient}
                            className="w-full"
                            width={1440}
                            height={1800}
                            alt="contact gradient background"
                        />
                    </div>
                </div>
                <div className={`relative ${isMobile ? "-top-[26%]" : "-top-[52%]"}`} style={{ zIndex: -1 }}>
                    <BackgroundCircles />
                </div>
            </div>
        </Section>
    );
};

export default Form;
